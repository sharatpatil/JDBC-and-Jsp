<?php

$con=mysql_connect("localhost","root","");
mysql_select_db("time",$con);

//get the posted values
$username= $_POST['t1'];
$password = $_POST['t2'];


//Check for Administrator login
$sql="select * from admin where username='$username' and password='$password'";

$result=mysql_query($sql);
$row=mysql_fetch_array($result);
if(mysql_num_rows($result)>0)
{

?>
<script>

		document.location="staff_add.html";
	</script>
	<?php
}
	

else

	{
		?>
		<script>
			alert('Invalid username or password...');
			document.location = "adminlog.html";
		</script>
		<?php
	
}
?>