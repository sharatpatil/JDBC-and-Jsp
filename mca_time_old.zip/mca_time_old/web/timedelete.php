<?php

$con=mysql_connect("localhost","root","");
$ql=mysql_select_db("time",$con);


$s=$_POST['hidden'];
	$deletequery="DELETE FROM timing WHERE time_id='$s'";
	mysql_query($deletequery,$con);
	
	
	?>
	
	 <script>
alert("deleted succesfully!!!");
document.location="time_details.php";
</script>