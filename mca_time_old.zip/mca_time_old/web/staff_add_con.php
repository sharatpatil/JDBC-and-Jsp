
<?php





$name=$_POST['t1'];
$email=$_POST['t2'];
$password=$_POST['t3'];
$staff_id=$_POST['t4'];
$address=$_POST['t5'];
$department=$_POST['t6'];
$sem=$_POST['t7'];



 
 $con=mysql_connect("localhost","root","");
$ql=mysql_select_db("time",$con);
 
 $query="insert into staff values('$name','$email','$password','$staff_id','$address','$department','$sem')";
 mysql_query($query);
 
 
 
 ?>
 <script>
alert("staff added Successfully");
document.location="staff_add.html";
</script>