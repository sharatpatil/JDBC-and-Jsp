<!--
Author: W3layouts
Author URL: http://w3layouts.com
License: Creative Commons Attribution 3.0 Unported
License URL: http://creativecommons.org/licenses/by/3.0/
-->
<!DOCTYPE html>
<html lang="zxx">

<head>
	<title>Best Study an Education Category Bootstrap Responsive Website Template | Register :: w3layouts</title>
	<!-- meta-tags -->
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
	<meta name="keywords" content="Soft Responsive web template, Bootstrap Web Templates, Flat Web Templates, Android Compatible web template, 
Smartphone Compatible web template, free webdesigns for Nokia, Samsung, LG, SonyEricsson, Motorola web design" />
	<script>
		addEventListener("load", function () {
			setTimeout(hideURLbar, 0);
		}, false);

		function hideURLbar() {
			window.scrollTo(0, 1);
		}
	</script>
	<!-- //meta-tags -->
	<link href="css/bootstrap.css" rel="stylesheet" type="text/css" media="all" />
	<link href="css/style.css" rel="stylesheet" type="text/css" media="all" />
	<!-- font-awesome -->
	<link href="css/font-awesome.css" rel="stylesheet">
	<!-- fonts -->
	<link href="//fonts.googleapis.com/css?family=Raleway:100,100i,200,200i,300,300i,400,400i,500,500i,600,600i,700,700i,800,800i,900,900i"
	    rel="stylesheet">
	<link href="//fonts.googleapis.com/css?family=Open+Sans:300,300i,400,400i,600,600i,700,700i,800,800i" rel="stylesheet">
</head>

<body>
	<!-- header -->
	<div class="header-top">
		<div class="container">
			<div class="bottom_header_left">
				<p>
					<span class="fa fa-map-marker" aria-hidden="true"></span>KLE Tech Hubli, India
				</p>
			</div>
			<div class="bottom_header_right">
				<div class="bottom-social-icons">
					<a class="facebook" href="#">
						<span class="fa fa-facebook"></span>
					</a>
					<a class="twitter" href="#">
						<span class="fa fa-twitter"></span>
					</a>
					<a class="pinterest" href="#">
						<span class="fa fa-pinterest-p"></span>
					</a>
					<a class="linkedin" href="#">
						<span class="fa fa-linkedin"></span>
					</a>
				</div>
				<div class="header-top-righ">
					<a href="index.html">
						<span class="fa fa-sign-out" aria-hidden="true"></span>Logout</a>
				</div>
				<div class="clearfix"> </div>
			</div>
			<div class="clearfix"> </div>
		</div>
	</div>
	<div class="header">
		<div class="content white">
			<nav class="navbar navbar-default">
				<div class="container">
					<div class="navbar-header">
						<button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1">
							<span class="sr-only">Toggle navigation</span>
							<span class="icon-bar"></span>
							<span class="icon-bar"></span>
							<span class="icon-bar"></span>
						</button>
						<a class="navbar-brand" href="index.html">
							<h1>
								<span class="fa fa-leanpub" aria-hidden="true"></span>KLE Tech University
								<label>Timetable generator</label>
							</h1>
						</a>
					</div>
					<!--/.navbar-header-->
					<div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
						<nav class="link-effect-2" id="link-effect-2">
							<ul class="nav navbar-nav">
								<li>
									<a href="staff_info.php" class="effect-3">Staff</a>
								</li>
								<li>
									<a href="select_sem.html" class="effect-3">Timetable</a>
								</li>
								
							</ul>
						</nav>
					</div>
					<!--/.navbar-collapse-->
					<!--/.navbar-->
				</div>
			</nav>
		</div>
	</div>
	<!-- banner -->
	<div class="inner_page_agile">

	</div>
	<!--//banner -->
	<!-- short-->
	<div class="services-breadcrumb">
		<div class="inner_breadcrumb">
			<ul class="short_ls">
				<li>
					<a href="index.html">Home</a>
					<span>| |</span>
				</li>
				<li>Department</li>
			</ul>
		</div>
	</div>
	<!-- //short-->
	<div class="register-form-main">
		<div class="container">
			<div class="title-div">
				<h3 class="tittle">
					<span>T</span>imetable<span> S</span>em3</h3>
				<div class="tittle-style">

				</div>
			</div>
			<?php
			 $con=mysql_connect("localhost","root","");
$sql=mysql_select_db("time",$con);
$sql="select * from timing where timing='08:00' and day='monday' and sem='3'";  
$res=mysql_query($sql);
$rowmon1=mysql_fetch_array($res);

$sql="select * from timing where timing='09:00' and day='monday' and sem='3'";  
$res=mysql_query($sql);
$rowmon2=mysql_fetch_array($res);


$sql="select * from timing where timing='10:15' and day='monday' and sem='3'";  
$res=mysql_query($sql);
$rowmon3=mysql_fetch_array($res);


$sql="select * from timing where timing='11:15' and day='monday' and sem='3'";  
$res=mysql_query($sql);
$rowmon4=mysql_fetch_array($res);

$sql="select * from timing where timing='01:30' and day='monday' and sem='3'";  
$res=mysql_query($sql);
$rowmon5=mysql_fetch_array($res);

$sql="select * from timing where timing='02:30' and day='monday' and sem='3'";  
$res=mysql_query($sql);
$rowmon6=mysql_fetch_array($res);

$sql="select * from timing where timing='03:30' and day='monday' and sem='3'";  
$res=mysql_query($sql);
$rowmon7=mysql_fetch_array($res);

$sql="select * from timing where timing='04:30' and day='monday' and sem='3'";  
$res=mysql_query($sql);
$rowmon8=mysql_fetch_array($res);



$sql="select * from timing where timing='08:00' and day='tuesday' and sem='3'";  
$res=mysql_query($sql);
$rowtue1=mysql_fetch_array($res);

$sql="select * from timing where timing='09:00' and day='tuesday' and sem='3'";  
$res=mysql_query($sql);
$rowtue2=mysql_fetch_array($res);

$sql="select * from timing where timing='10:15' and day='tuesday' and sem='3'";  
$res=mysql_query($sql);
$rowtue3=mysql_fetch_array($res);

$sql="select * from timing where timing='11:15' and day='tuesday' and sem='3'";  
$res=mysql_query($sql);
$rowtue4=mysql_fetch_array($res);

$sql="select * from timing where timing='01:30' and day='tuesday' and sem='3'";  
$res=mysql_query($sql);
$rowtue5=mysql_fetch_array($res);

$sql="select * from timing where timing='02:30' and day='tuesday' and sem='3'";  
$res=mysql_query($sql);
$rowtue6=mysql_fetch_array($res);

$sql="select * from timing where timing='03:30' and day='tuesday' and sem='3'";  
$res=mysql_query($sql);
$rowtue7=mysql_fetch_array($res);

$sql="select * from timing where timing='04:30' and day='tuesday' and sem='3'";  
$res=mysql_query($sql);
$rowtue8=mysql_fetch_array($res);



$sql="select * from timing where timing='08:00' and day='wednesday' and sem='3'";  
$res=mysql_query($sql);
$rowwed1=mysql_fetch_array($res);

$sql="select * from timing where timing='09:00' and day='wednesday' and sem='3'";  
$res=mysql_query($sql);
$rowwed2=mysql_fetch_array($res);

$sql="select * from timing where timing='10:15' and day='wednesday' and sem='3'";  
$res=mysql_query($sql);
$rowwed3=mysql_fetch_array($res);

$sql="select * from timing where timing='11:15' and day='wednesday' and sem='3'";  
$res=mysql_query($sql);
$rowwed4=mysql_fetch_array($res);

$sql="select * from timing where timing='01:30' and day='wednesday' and sem='3'";  
$res=mysql_query($sql);
$rowwed5=mysql_fetch_array($res);

$sql="select * from timing where timing='02:30' and day='wednesday' and sem='3'";  
$res=mysql_query($sql);
$rowwed6=mysql_fetch_array($res);

$sql="select * from timing where timing='03:30' and day='wednesday' and sem='3'";  
$res=mysql_query($sql);
$rowwed7=mysql_fetch_array($res);

$sql="select * from timing where timing='04:30' and day='wednesday' and sem='3'";  
$res=mysql_query($sql);
$rowwed8=mysql_fetch_array($res);



$sql="select * from timing where timing='08:00' and day='thursday' and sem='3'";  
$res=mysql_query($sql);
$rowthr1=mysql_fetch_array($res);

$sql="select * from timing where timing='09:00' and day='thursday' and sem='3'";  
$res=mysql_query($sql);
$rowthr2=mysql_fetch_array($res);

$sql="select * from timing where timing='10:15' and day='thursday' and sem='3'";  
$res=mysql_query($sql);
$rowthr3=mysql_fetch_array($res);

$sql="select * from timing where timing='11:15' and day='thursday' and sem='3'";  
$res=mysql_query($sql);
$rowthr4=mysql_fetch_array($res);

$sql="select * from timing where timing='01:30' and day='thursday' and sem='3'";  
$res=mysql_query($sql);
$rowthr5=mysql_fetch_array($res);

$sql="select * from timing where timing='02:30' and day='thursday' and sem='3'";  
$res=mysql_query($sql);
$rowthr6=mysql_fetch_array($res);

$sql="select * from timing where timing='03:30' and day='thursday' and sem='3'";  
$res=mysql_query($sql);
$rowthr7=mysql_fetch_array($res);

$sql="select * from timing where timing='04:30' and day='thursday' and sem='3'";  
$res=mysql_query($sql);
$rowthr8=mysql_fetch_array($res);




$sql="select * from timing where timing='08:00' and day='friday' and sem='3'";  
$res=mysql_query($sql);
$rowfri1=mysql_fetch_array($res);

$sql="select * from timing where timing='09:00' and day='friday' and sem='3'";  
$res=mysql_query($sql);
$rowfri2=mysql_fetch_array($res);

$sql="select * from timing where timing='10:15' and day='friday' and sem='3'";  
$res=mysql_query($sql);
$rowfri3=mysql_fetch_array($res);

$sql="select * from timing where timing='11:15' and day='friday' and sem='3'";  
$res=mysql_query($sql);
$rowfri4=mysql_fetch_array($res);

$sql="select * from timing where timing='01:30' and day='friday' and sem='3'";  
$res=mysql_query($sql);
$rowfri5=mysql_fetch_array($res);

$sql="select * from timing where timing='02:30' and day='friday' and sem='3'";  
$res=mysql_query($sql);
$rowfri6=mysql_fetch_array($res);

$sql="select * from timing where timing='03:30' and day='friday' and sem='3'";  
$res=mysql_query($sql);
$rowfri7=mysql_fetch_array($res);

$sql="select * from timing where timing='04:30' and day='friday' and sem='3'";  
$res=mysql_query($sql);
$rowfri8=mysql_fetch_array($res);



$sql="select * from timing where timing='08:00' and day='saturday' and sem='3'";  
$res=mysql_query($sql);
$rowsat1=mysql_fetch_array($res);

$sql="select * from timing where timing='09:00' and day='saturday' and sem='3'";  
$res=mysql_query($sql);
$rowsat2=mysql_fetch_array($res);

$sql="select * from timing where timing='10:15' and day='saturday' and sem='3'";  
$res=mysql_query($sql);
$rowsat3=mysql_fetch_array($res);

$sql="select * from timing where timing='11:15' and day='saturday' and sem='3'";  
$res=mysql_query($sql);
$rowsat4=mysql_fetch_array($res);

$sql="select * from timing where timing='01:30' and day='saturday' and sem='3'";  
$res=mysql_query($sql);
$rowsat5=mysql_fetch_array($res);

$sql="select * from timing where timing='02:30' and day='saturday' and sem='3'";  
$res=mysql_query($sql);
$rowsat6=mysql_fetch_array($res);

$sql="select * from timing where timing='03:30' and day='saturday' and sem='3'";  
$res=mysql_query($sql);
$rowsat7=mysql_fetch_array($res);

$sql="select * from timing where timing='04:30' and day='saturday' and sem='3'";  
$res=mysql_query($sql);
$rowsat8=mysql_fetch_array($res);





?>
		  <div class="login-form">
		    <table width="613" height="264" border="1">
              <tr>
                <th colspan="11" scope="col"><div align="center">TIMETABLE OF THIRD SEMISTER </div></th>
              </tr>
              <tr>
                <th scope="row"><div align="center">DAY/TIME</div></th>
                <td><strong> 8:00 to 9:00  </strong></td>
                <td><strong>9:00 to 10:00 </strong></td>
                <td rowspan="7"><p><strong>B</strong></p>
                <p><strong>R</strong></p>
                <p><strong>E</strong></p>
                <p><strong>A</strong></p>
                <p><strong>K</strong></p></td>
                <td><strong>10:15 to 11:15 </strong></td>
                <td><strong>11:15 to 12:15 </strong></td>
                <td rowspan="7"><p><strong>B</strong></p>
                  <p><strong>R</strong></p>
                  <p><strong>E</strong></p>
                  <p><strong>A</strong></p>
                <p><strong>K</strong></p></td>
                <td><strong>1:30 to 2:30</strong></td>
                <td><strong>2:30 to 3:30 </strong></td>
                <td><strong>3:30 to 4:30</strong></td>
                <td><strong>4:30 to 5:30 </strong></td>
              </tr>
              <tr>
                <th scope="row">Monday</th>
				
                <td><div align="center">
                  <?php  echo $rowmon1['cname']; ?>
                </div></td>
                <td><div align="center">
                  <?php   echo $rowmon2['cname'];?>
                </div></td>
                <td><div align="center">
                  <?php echo $rowmon3['cname']; ?>
                </div></td>
                <td><div align="center">
                  <?php  echo $rowmon4['cname']; ?>
                </div></td>
                <td><div align="center">
                  <?php  echo $rowmon5['cname']; ?>
                </div></td>
                <td><div align="center">
                  <?php  echo $rowmon6['cname']; ?>
                </div></td>
                <td><div align="center">
                  <?php   echo $rowmon7['cname']; ?>
                </div></td>
                <td><div align="center">
                  <?php  echo $rowmon8['cname']; ?>
                </div></td>
              </tr>
              <tr>
                <th scope="row">Tuesday</th>
                <td><div align="center">
                  <?php echo $rowtue1['cname']; ?>
                </div></td>
                <td><div align="center">
                  <?php   echo $rowtue2['cname'];?>
                </div></td>
                <td><div align="center">
                  <?php  echo $rowtue3['cname']; ?>
                </div></td>
                <td><div align="center">
                  <?php   echo $rowtue4['cname']; ?>
                </div></td>
                <td><div align="center">
                  <?php echo $rowtue5['cname']; ?>
                </div></td>
                <td><div align="center">
                  <?php  echo $rowtue6['cname']; ?>
                </div></td>
                <td><div align="center">
                  <?php  echo $rowtue7['cname']; ?>
                </div></td>
                <td><div align="center">
                  <?php   echo $rowtue8['cname']; ?>
                </div></td>
              </tr>
              <tr>
                <th scope="row">Wednesday</th>
                <td><div align="center">
                  <?php  echo $rowwed1['cname']; ?>
                </div></td>
                <td><div align="center">
                  <?php  echo $rowwed2['cname']; ?>
                </div></td>
                <td><div align="center">
                  <?php  echo $rowwed3['cname']; ?>
                </div></td>
                <td><div align="center">
                  <?php  echo $rowwed4['cname']; ?>
                </div></td>
                <td><div align="center">
                  <?php  echo $rowwed5['cname']; ?>
                </div></td>
                <td><div align="center">
                  <?php  echo $rowwed6['cname']; ?>
                </div></td>
                <td><div align="center">
                  <?php  echo $rowwed7['cname']; ?>
                </div></td>
                <td><div align="center">
                  <?php  echo $rowwed8['cname']; ?>
                </div></td>
              </tr>
              <tr>
                <th scope="row">Thursday</th>
                <td><div align="center">
                  <?php  echo $rowthr1['cname']; ?>
                </div></td>
                <td><div align="center">
                  <?php  echo $rowthr2['cname']; ?>
                </div></td>
                <td><div align="center">
                  <?php  echo $rowthr3['cname']; ?>
                </div></td>
                <td><div align="center">
                  <?php  echo $rowthr4['cname']; ?>
                </div></td>
                <td><div align="center">
                  <?php  echo $rowthr5['cname']; ?>
                </div></td>
                <td><div align="center">
                  <?php  echo $rowthr6['cname']; ?>
                </div></td>
                <td><div align="center">
                  <?php  echo $rowthr7['cname']; ?>
                </div></td>
                <td><div align="center">
                  <?php  echo $rowthr8['cname']; ?>
                </div></td>
              </tr>
              <tr>
                <th scope="row">Friday</th>
                <td><div align="center">
                  <?php  echo $rowfri1['cname']; ?>
                </div></td>
                <td><div align="center">
                  <?php  echo $rowfri2['cname']; ?>
                </div></td>
                <td><div align="center">
                  <?php  echo $rowfri3['cname']; ?>
                </div></td>
                <td><div align="center">
                  <?php  echo $rowfri4['cname']; ?>
                </div></td>
                <td><div align="center">
                  <?php  echo $rowfri5['cname']; ?>
                </div></td>
                <td><div align="center">
                  <?php  echo $rowfri6['cname']; ?>
                </div></td>
                <td><div align="center">
                  <?php  echo $rowfri7['cname']; ?>
                </div></td>
                <td><div align="center">
                  <?php  echo $rowfri8['cname']; ?>
                </div></td>
              </tr>
              <tr>
                <th scope="row">Saturday</th>
                <td><div align="center">
                  <?php  echo $rowsat1['cname']; ?>
                </div></td>
                <td><div align="center">
                  <?php  echo $rowsat2['cname']; ?>
                </div></td>
                <td><div align="center">
                  <?php  echo $rowsat3['cname']; ?>
                </div></td>
                <td><div align="center">
                  <?php  echo $rowsat4['cname']; ?>
                </div></td>
                <td><div align="center">
                  <?php  echo $rowsat5['cname']; ?>
                </div></td>
                <td><div align="center">
                  <?php  echo $rowsat6['cname']; ?>
                </div></td>
                <td><div align="center">
                  <?php  echo $rowsat7['cname']; ?>
                </div></td>
                <td><div align="center">
                  <?php  echo $rowsat8['cname']; ?>
                </div></td>
              </tr>
            </table>
		  </div>

		</div>
	</div>
<div align="center">
	  <input type="button" onClick="window.print()" value="print" />
	  
	  <!-- footer -->
</div>
	<div class="mkl_footer">
		<div class="sub-footer">
			<div class="container">
				<div class="mkls_footer_grid">
					<div class="col-xs-4 mkls_footer_grid_left">
						<h4>Location:</h4>
						<p>educa mfdflimbg 1235, Ipswich,
							<br> Foxhall Road, USA</p>
					</div>
					<div class="col-xs-4 mkls_footer_grid_left">
						<h4>Mail Us:</h4>
						<p>
							<span>Phone : </span>001 234 5678</p>
						<p>
							<span>Email : </span>
							<a href="mailto:info@example.com">mail@example.com</a>
						</p>
					</div>
					<div class="col-xs-4 mkls_footer_grid_left">
						<h4>Opening Hours:</h4>
						<p>Working days : 8am-10pm</p>
						<p>Sunday
							<span>(closed)</span>
						</p>
					</div>
					<div class="clearfix"> </div>
				</div>
				<div class="botttom-nav-allah">
					<ul>
						<li>
							<a href="index.html">Home</a>
						</li>
						<li>
							<a href="about.html">About Us</a>
						</li>
						<li>
							<a href="courses.html">Courses</a>
						</li>
						<li>
							<a href="join.html">Join Us</a>
						</li>
						<li>
							<a href="contact.html">Contact Us</a>
						</li>
					</ul>
				</div>
				<!-- footer-button-info -->
				<div class="footer-middle-thanks">
					<h2>Thanks For watching</h2>
				</div>
				<!-- footer-button-info -->
			</div>
		</div>
		<div class="footer-copy-right">
			<div class="container">
				<div class="allah-copy">
					<p>© 2018 Best Study. All rights reserved | Design by
						<a href="http://w3layouts.com/">W3layouts</a>
					</p>
				</div>
				<div class="footercopy-social">
					<ul>
						<li>
							<a href="#">
								<span class="fa fa-facebook"></span>
							</a>
						</li>
						<li>
							<a href="#">
								<span class="fa fa-twitter"></span>
							</a>
						</li>
						<li>
							<a href="#">
								<span class="fa fa-rss"></span>
							</a>
						</li>
						<li>
							<a href="#">
								<span class="fa fa-vk"></span>
							</a>
						</li>
					</ul>
				</div>
				<div class="clearfix"></div>
			</div>
		</div>
	</div>
	<!--/footer -->

	<!-- js files -->
	<!-- js -->
	<script src="js/jquery-2.1.4.min.js"></script>
	<!-- bootstrap -->
	<script src="js/bootstrap.js"></script>
	<!-- smooth scrolling -->
	<script src="js/SmoothScroll.min.js"></script>
	<script src="js/move-top.js"></script>
	<script src="js/easing.js"></script>
	<!-- here stars scrolling icon -->
	<script>
		$(document).ready(function () {
			/*
				var defaults = {
				containerID: 'toTop', // fading element id
				containerHoverID: 'toTopHover', // fading element hover id
				scrollSpeed: 1200,
				easingType: 'linear' 
				};
			*/

			$().UItoTop({
				easingType: 'easeOutQuart'
			});

		});
	</script>
	<!-- //here ends scrolling icon -->
	<!-- smooth scrolling -->
	<!-- password-script -->
	<script>
		window.onload = function () {
			document.getElementById("password1").onchange = validatePassword;
			document.getElementById("password2").onchange = validatePassword;
		}

		function validatePassword() {
			var pass2 = document.getElementById("password2").value;
			var pass1 = document.getElementById("password1").value;
			if (pass1 != pass2)
				document.getElementById("password2").setCustomValidity("Passwords Don't Match");
			else
				document.getElementById("password2").setCustomValidity('');
			//empty string means no validation error
		}
	</script>
	<!-- //password-script -->
	<!-- //js-files -->

</body>

</html>