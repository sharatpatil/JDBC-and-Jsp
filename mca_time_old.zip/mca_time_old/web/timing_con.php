
<?php





$cname=$_POST['s1'];
$staff=$_POST['s2'];
$room=$_POST['s3'];
$timing=$_POST['s4'];
$day=$_POST['s5'];
$sem=$_POST['s6'];

$n1=rand(11,99);
$n2=rand(22,99);
$n3=rand(22,99);
$n4=rand(22,99);
$n5=rand(22,99);


$time_id=$n1.$n2.$n3.$n4.$n5;
 
 $con=mysql_connect("localhost","root","");
$ql=mysql_select_db("time",$con);

$sql="select * from timing where timing='$timing' and day='$day' and sem='$sem'";  
$res=mysql_query($sql);
$row=mysql_fetch_array($res);
 
$time=mysql_query("select time_id from timing where timing='$timing' and day='$day' and sem='$sem';");
$time_id_fetch=mysql_fetch_array($time); 
$time_org=$time_id_fetch['time_id'];


if($time_org==NULL)
{

$query="insert into timing values('$time_id','$cname','$staff','$room','$timing','$day','$sem')";
 mysql_query($query);
 ?>
 
 <script>
alert("timetable added Successfully");
document.location="timing.php";
</script>
<?php
}

if($time_org==$row['time_id'])
{
 
?>
 
 <script>
alert("already allocated to this time and day");
document.location="timing.php";
</script>
 

 

<?php
}
?>