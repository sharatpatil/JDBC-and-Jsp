
<?php





$username=$_POST['t1'];
$password=$_POST['t2'];



 
 $con=mysql_connect("localhost","root","");
$ql=mysql_select_db("time",$con);
 
 $query="insert into login values('$username','$password')";
 mysql_query($query);
 
 
 
 ?>
 <script>
alert("Registered Successfully");
document.location="login.html";
</script>