
<?php





$name=$_POST['t1'];
$email=$_POST['t2'];
$pno=$_POST['t3'];
$msg=$_POST['t4'];




 
 $con=mysql_connect("localhost","root","");
$ql=mysql_select_db("time",$con);
 
 $query="insert into contact values('$name','$email','$pno','$msg')";
 mysql_query($query);
 
 
 
 ?>
 <script>
alert("msg Added Successfully");
document.location="contact.html";
</script>