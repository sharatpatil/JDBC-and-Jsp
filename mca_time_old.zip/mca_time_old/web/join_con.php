
<?php





$name=$_POST['t1'];
$gender=$_POST['t2'];
$mail=$_POST['t3'];
$pnum=$_POST['t4'];
$course=$_POST['t5'];
$address=$_POST['t6'];
$pincode=$_POST['t7'];



 
 $con=mysql_connect("localhost","root","");
$ql=mysql_select_db("time",$con);
 
 $query="insert into join values('$name','$gender','$mail','$pnum','$course','$address','$pincode')";
 mysql_query($query);
 

 
 ?>
 <script>
alert("added Successfully");
document.location="join.html";
</script>