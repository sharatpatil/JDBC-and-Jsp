<?php

$con=mysql_connect("localhost","root","");
$ql=mysql_select_db("time",$con);


$s=$_POST['hidden'];
	$deletequery="DELETE FROM staff WHERE name='$s'";
	mysql_query($deletequery,$con);
	
	
	?>
	
	 <script>
alert("deleted succesfully!!!");
document.location="admin_staff.php";
</script>