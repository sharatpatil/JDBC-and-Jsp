
<?php





$department=$_POST['t1'];
$d_id=$_POST['t2'];



 
 $con=mysql_connect("localhost","root","");
$ql=mysql_select_db("time",$con);
 
 $query="insert into department values('$department','$d_id')";
 mysql_query($query);
 
 
 
 ?>
 <script>
alert("Department Added Successfully");
document.location="department_add.html";
</script>