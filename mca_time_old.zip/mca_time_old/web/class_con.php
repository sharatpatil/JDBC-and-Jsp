
<?php





$room=$_POST['t1'];
$capacity=$_POST['t2'];



 
 $con=mysql_connect("localhost","root","");
$ql=mysql_select_db("time",$con);
 
 $query="insert into room values('$room','$capacity')";
 mysql_query($query);
 
 
 
 ?>
 <script>
alert("class rooom Added Successfully");
document.location="class_add.html";
</script>