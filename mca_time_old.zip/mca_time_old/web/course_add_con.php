
<?php





$cname=$_POST['t1'];
$cid=$_POST['t2'];
$sem_id=$_POST['t3'];
$department_id=$_POST['t4'];




 
 $con=mysql_connect("localhost","root","");
$ql=mysql_select_db("time",$con);
 
 $query="insert into course values('$cname','$cid','$sem_id','$department_id')";
 mysql_query($query);
 
 
 
 ?>
 <script>
alert("course added Successfully");
document.location="course_add.html";
</script>